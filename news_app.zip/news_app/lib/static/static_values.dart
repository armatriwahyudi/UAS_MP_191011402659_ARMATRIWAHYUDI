import 'package:flutter/material.dart';

const kApiURLDomain = 'api.indosiana.com';
const kApiEndPoint = 'api/articles';
const kApiKey = 'e818e4eff18543059cf61c3e20652b37';

const kPrimaryColor = Colors.redAccent;
