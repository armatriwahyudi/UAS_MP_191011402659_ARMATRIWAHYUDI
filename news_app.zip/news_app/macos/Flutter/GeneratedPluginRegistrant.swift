//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import wakelock_macos

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  WakelockMacosPlugin.register(with: registry.registrar(forPlugin: "WakelockMacosPlugin"))
}
